// --- SECCIÓN: RECEPCIÓN DE DATOS (DOM) ---
// MEJORA: Esta función "crearFila" técnicamente pertenece al Controlador (client_controller.js).
// La comentamos aquí para que el Servicio sea puro, pero mantienes la lógica por si la necesitas.

/* const crearFila = (nombre, email, id) => { 
    const fila = document.createElement("tr"); 
    const conntenido = `
    <td class="td" data-td>${nombre}</td>
    <td>${email}</td>
    <td>
      <ul class="table__button-control">
        <li>
          <a href="../screens/editar_cliente.html?id=${id}" class="simple-button simple-button--edit">Editar</a>
        </li>
        <li>
          <button class="simple-button simple-button--delete" type="button" id="${id}">Eliminar</button>
        </li>
      </ul>
    </td>`;
    fila.innerHTML = conntenido;
    
    const btn = fila.querySelector("button");
    btn.addEventListener("click", () => {
        const id = btn.id;
        clientService.eliminarCliente(id).then(() => {
            fila.remove(); 
        });
    });
    return fila;
};
*/

// const table = document.querySelector("[data-table]"); 

// --- SECCIÓN: CONEXIÓN (PROMESAS / FETCH) ---

/* Mantenemos tu código antiguo con XMLHttpRequest como comentario pedagógico:
const listar_clientes=()=>{ ... }
*/

// MEJORA: Centralizamos la URL en una constante para no repetirla (Principio DRY)
const url_perfil = "http://localhost:3000/perfil";

const listar_clientes = () =>
    fetch(url_perfil)
        .then((respuesta) => {
            if (!respuesta.ok) throw new Error("Error al obtener los datos");
            return respuesta.json();
        });

const crearCliente = (nombre, email) => {
    return fetch(url_perfil, {
        method: "POST",
        headers: { "content-type": "application/json" },
        // MEJORA: Validar que uuid esté disponible antes de llamar
        body: JSON.stringify({ nombre, email, id: typeof uuid !== 'undefined' ? uuid.v4() : null })
    })
};

const actualizarCliente = (nombre, email, id) => {
    return fetch(`http://localhost:3000/perfil/${id}`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ nombre, email })
    })
    .then((respuesta) => respuesta) 
    .catch((err) => console.log(err));
};

const eliminarCliente = (id) => {
    return fetch(`http://localhost:3000/perfil/${id}`, {
        method: "DELETE"

    })
    .then((respuesta) => respuesta)
    .catch((err) => console.log(err));
};

const cliente = (id) => {
    return fetch(`http://localhost:3000/perfil/${id}`)
    .then((respuesta) => respuesta.json());
}


/*
listar_clientes()
    .then((data) => {
        data.forEach((perfil) => {
            const nuevaFila = crearFila(perfil.nombre, perfil.email, perfil.id);
            if(table) table.appendChild(nuevaFila);
        });
    })
    .catch((error) => {
        console.error(error);
        alert("No existe conexión");
    });
*/

// SECCIÓN: EXPORTACIÓN

export const clientService = {
    listar_clientes,
    crearCliente,
    actualizarCliente,
    eliminarCliente,
    cliente
};